using System.Collections;
using UnityEngine;

public class ItemDropping
{
    private GameObject playerCharacter;
    private GameObject droppedItemPrefab;
    private Movement playerMovementScript;
    private float throwForce;

    public ItemDropping(GameObject playerCharacter, GameObject droppedItemPrefab, Movement playerMovementScript, float throwForce)
    {
        this.playerCharacter = playerCharacter;
        this.droppedItemPrefab = droppedItemPrefab;
        this.playerMovementScript = playerMovementScript;
        this.throwForce = throwForce;
    }

    public void DropItem(Vector2 mousePosition, EquipmentDefinition itemToBeDropped)
    {
        // Instantiate the dropped item prefab
        GameObject droppedItemInstance = Object.Instantiate(droppedItemPrefab, playerCharacter.transform.position, Quaternion.identity);
        ItemPickup itemPickup = droppedItemInstance.GetComponent<ItemPickup>();

        if (itemPickup != null)
        {
            // Set the item data in the ItemPickup component
            itemPickup.item = itemToBeDropped;

            // Calculate force direction
            Vector2 mouseWorldPosition = Camera.main.ScreenToWorldPoint(mousePosition);
            Vector2 throwDirection = (mouseWorldPosition - (Vector2)playerCharacter.transform.position).normalized;

            // Adjust the item's position to avoid collisions
            float halfItemWidth = itemPickup.GetComponent<SpriteRenderer>().bounds.extents.x;
            droppedItemInstance.transform.position += (Vector3)throwDirection * halfItemWidth;

            // Apply force to throw the dropped item
            Vector3 force = new Vector3(playerMovementScript.side * throwForce, throwForce, 0);
            Throw(itemPickup, force, playerMovementScript.GetComponent<Rigidbody2D>().velocity);
        }
        else
        {
            Debug.LogError("ItemPickup component not found on the dropped item prefab.");
        }
    }

    public void Throw(ItemPickup itemPickup, Vector3 force, Vector3 playerVelocity)
    {
        itemPickup.StartCoroutine(ApplyThrowForce(itemPickup, force, playerVelocity));
    }
    private float timeSinceThrown;

    private IEnumerator ApplyThrowForce(ItemPickup itemPickup, Vector3 force, Vector3 playerVelocity)
    {
        Rigidbody2D rb = itemPickup.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.AddForce(force + playerVelocity, ForceMode2D.Impulse);
            itemPickup.SetTimeSinceThrown(Time.time);
            itemPickup.StartCoroutine(DisablePickupTemporarily(itemPickup));
        }
        yield return null;
    }


    private IEnumerator DisablePickupTemporarily(ItemPickup itemPickup)
    {
        Collider2D collider = itemPickup.GetComponent<Collider2D>();
        if (collider != null)
        {
            Physics2D.IgnoreLayerCollision(itemPickup.gameObject.layer, itemPickup.playerLayer, true);
            yield return new WaitForSeconds(itemPickup.pickupDelay);
            Physics2D.IgnoreLayerCollision(itemPickup.gameObject.layer, itemPickup.playerLayer, false);
        }
    }
}
