using UnityEngine;
using UnityEngine.UIElements;
using System.Linq;
using System.Collections;

public class InventoryUI : MonoBehaviour
{
    private EquipmentManager equipmentManager;
    private VisualElement root;
    private Image currentSlotIcon;
    private Image draggedItem;
    private bool isDraggingOutside;
    [SerializeField] private GameObject droppedItemPrefab;

    private string currentSlotId;

    public GameObject playerCharacter;
    public float throwForce = 7f;
    public Movement playerMovementScript;
    [SerializeField] private LayerMask groundLayer;
    private ItemDropping itemDropping;

    private void Start()
    {
        equipmentManager = Object.FindObjectOfType<EquipmentManager>();
        if (equipmentManager == null)
        {
            Debug.LogError("EquipmentManager not found.");
            return;
        }

        root = GetComponent<UIDocument>().rootVisualElement;
        equipmentManager.OnEquipmentChanged += UpdateEquipmentSlot;

        root.RegisterCallback<MouseUpEvent>(OnGlobalMouseUp);
        root.RegisterCallback<MouseMoveEvent>(OnGlobalMouseMove);

        itemDropping = new ItemDropping(playerCharacter, droppedItemPrefab, playerMovementScript, throwForce);
    }

    private void OnDestroy()
    {
        if (equipmentManager != null)
        {
            equipmentManager.OnEquipmentChanged -= UpdateEquipmentSlot;
        }

        if (root != null)
        {
            root.UnregisterCallback<MouseUpEvent>(OnGlobalMouseUp);
            root.UnregisterCallback<MouseMoveEvent>(OnGlobalMouseMove);
        }
    }

    private void UpdateEquipmentSlot(EquipmentDefinition equipment, string slotType)
    {
        string slotID = slotType + "Icon";
        Image slotIcon = root.Q<Image>(slotID);

        if (slotIcon != null)
        {
            if (equipment != null)
            {
                slotIcon.sprite = equipment.Icon;
                slotIcon.RegisterCallback<MouseMoveEvent>(OnSlotIconMouseMove);
            }
            else
            {
                slotIcon.sprite = null;
                slotIcon.UnregisterCallback<MouseMoveEvent>(OnSlotIconMouseMove);
            }
        }
        else
        {
            Debug.LogWarning($"Icon with ID '{slotID}' not found.");
        }
    }

    private void OnSlotIconMouseMove(MouseMoveEvent evt)
    {
        if (Input.GetMouseButton(0) && currentSlotIcon == null)
        {
            currentSlotIcon = evt.currentTarget as Image;
            if (currentSlotIcon != null)
            {
                currentSlotIcon.style.opacity = 0.5f;
                draggedItem = new Image
                {
                    sprite = currentSlotIcon.sprite,
                    style =
        {
            position = Position.Absolute,
            width = currentSlotIcon.layout.width,
            height = currentSlotIcon.layout.height,
            opacity = 0f
        }
                };
                root.Add(draggedItem);
                UpdateDraggedItemPosition(evt.mousePosition);
                StartCoroutine(FadeIn(draggedItem, 0.6f));

                // Add this Debug.Log statement
                currentSlotId = currentSlotIcon.name.Replace("Icon", "");
            }
        }
    }

    IEnumerator FadeIn(Image img, float duration)
    {
        float startTime = Time.time;
        while (img.style.opacity.value < 1f)
        {
            float t = (Time.time - startTime) / duration;
            img.style.opacity = Mathf.SmoothStep(0f, 6f, t);
            yield return null;
        }
    }

    private void UpdateDraggedItemPosition(Vector2 mousePosition)
    {
        if (draggedItem != null)
        {
            draggedItem.style.left = mousePosition.x - draggedItem.layout.width / 2;
            draggedItem.style.top = mousePosition.y - draggedItem.layout.height / 2;
        }
    }

    private void OnGlobalMouseUp(MouseUpEvent evt)
    {
        if (currentSlotId != null)
        {
            EquipmentDefinition itemToBeDropped = equipmentManager.GetEquipmentSlot(currentSlotId).equippedItem;

            if (currentSlotIcon != null)
            {
                currentSlotIcon.style.opacity = 1.0f;
                currentSlotIcon = null;
            }

            if (draggedItem != null)
            {
                if (isDraggingOutside)
                {
                    itemDropping.DropItem(evt.mousePosition, itemToBeDropped);
                    equipmentManager.UnequipItemInstance(itemToBeDropped);
                }

                root.Remove(draggedItem);
                draggedItem = null;
                currentSlotId = null;
            }
            else
            {
                Debug.LogWarning("Equipment slot not found for: " + currentSlotId);
            }
        }
    }

    private void OnGlobalMouseMove(MouseMoveEvent evt)
    {
        if (draggedItem != null)
        {
            UpdateDraggedItemPosition(evt.mousePosition);

            VisualElement inventoryPanel = root.Q<VisualElement>("InvContainer");
            Rect panelRect = new Rect(inventoryPanel.layout.position, inventoryPanel.layout.size);
            Vector2 mousePos = evt.mousePosition;
            isDraggingOutside = !panelRect.Contains(mousePos);

            if (isDraggingOutside)
            {
                if (!draggedItem.Children().Any(child => child.name == "DroppingLabel"))
                {
                    var droppingLabel = new Label("Dropping")
                    {
                        name = "DroppingLabel",
                        style =
                        {
                        unityTextAlign = TextAnchor.MiddleCenter,
                        fontSize = 16,
                        color = Color.white,
                        position = Position.Absolute,
                        top = -30,
                        left = draggedItem.layout.width / 2 - 50,
                        width = 100
                        }
                    };
                    draggedItem.Add(droppingLabel);
                }
            }
            else
            {
                draggedItem.Q<Label>("DroppingLabel")?.RemoveFromHierarchy();
            }
        }
    }


    public void UpdateInventoryDisplay()
    {
        // Assuming GetAllItemsInStorage() is implemented in EquipmentManager
        List<ItemStack> allItems = equipmentManager.GetAllItemsInStorage();

        // Assuming invScrollView is correctly initialized
        invScrollView.Clear();

        // Create the tinyEquipmentView
        VisualElement tinyEquipmentView = new VisualElement();
        tinyEquipmentView.style.borderTopWidth = tinyEquipmentView.style.borderRightWidth = tinyEquipmentView.style.borderBottomWidth = tinyEquipmentView.style.borderLeftWidth = 1;
        tinyEquipmentView.style.borderTopColor = tinyEquipmentView.style.borderRightColor = tinyEquipmentView.style.borderBottomColor = tinyEquipmentView.style.borderLeftColor = new Color(83f / 255f, 65f / 255f, 65f / 255f);
        tinyEquipmentView.style.backgroundColor = new Color(49f / 255f, 37f / 255f, 37f / 255f);
        invScrollView.Add(tinyEquipmentView);

        // Create the grid container
        VisualElement gridContainer = new VisualElement();
        gridContainer.style.borderTopWidth = gridContainer.style.borderRightWidth = gridContainer.style.borderBottomWidth = gridContainer.style.borderLeftWidth = 1;
        gridContainer.style.borderTopColor = gridContainer.style.borderRightColor = gridContainer.style.borderBottomColor = gridContainer.style.borderLeftColor = new Color(55f / 255f, 55f / 255f, 55f / 255f);
        gridContainer.style.backgroundColor = new Color(56f / 255f, 56f / 255f, 56f / 255f, 0.38f);
        invScrollView.Add(gridContainer);

        // Populate the grid with items
        foreach (ItemStack itemStack in allItems)
        {
            VisualElement itemSlot = new VisualElement();
            if (itemStack != null)
            {
                itemSlot.style.borderTopWidth = itemSlot.style.borderRightWidth = itemSlot.style.borderBottomWidth = itemSlot.style.borderLeftWidth = 2;
                itemSlot.style.borderTopColor = itemSlot.style.borderRightColor = itemSlot.style.borderBottomColor = itemSlot.style.borderLeftColor = new Color(71f / 255f, 71f / 255f, 71f / 255f);
                itemSlot.style.backgroundColor = new Color(47f / 255f, 47f / 255f, 47f / 255f);
            }
            else
            {
                itemSlot.style.backgroundColor = new Color(24f / 255f, 24f / 255f, 24f / 255f);
            }
            gridContainer.Add(itemSlot);
        }
    }




}